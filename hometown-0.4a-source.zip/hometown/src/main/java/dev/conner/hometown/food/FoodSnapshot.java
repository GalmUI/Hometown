package dev.conner.hometown.food;

import java.util.OptionalDouble;
import java.util.OptionalInt;

/** Server-derived reserves only. No inventory references or persistent data. */
public record FoodSnapshot(int population, int foodContainers, int foodStacks, int uniqueFoodTypes,
        long totalNutrition, long dailyNutritionRequirement, OptionalDouble reserveDays,
        FoodSecurityState state, boolean scanComplete, OptionalInt barPercent) {
    public enum FoodSecurityState { NO_RESIDENTS, EMPTY, CRITICAL, LOW, STABLE, STOCKED, SCAN_INCOMPLETE }
    public FoodSnapshot {
        java.util.Objects.requireNonNull(reserveDays); java.util.Objects.requireNonNull(state); java.util.Objects.requireNonNull(barPercent);
        if (population < 0 || foodContainers < 0 || foodStacks < 0 || uniqueFoodTypes < 0 || totalNutrition < 0 || dailyNutritionRequirement < 0
                || foodContainers > foodStacks || uniqueFoodTypes > foodStacks
                || scanComplete == (state == FoodSecurityState.SCAN_INCOMPLETE)
                || reserveDays.isPresent() != (scanComplete && population > 0) || reserveDays.isPresent() != barPercent.isPresent()
                || (reserveDays.isPresent() && (!Double.isFinite(reserveDays.getAsDouble()) || reserveDays.getAsDouble() < 0))
                || (barPercent.isPresent() && (barPercent.getAsInt() < 0 || barPercent.getAsInt() > 100)))
            throw new IllegalArgumentException("Invalid Food snapshot");
    }
    public static FoodSnapshot unavailable(int population) {
        return new FoodSnapshot(population,0,0,0,0,0,OptionalDouble.empty(),FoodSecurityState.SCAN_INCOMPLETE,false,OptionalInt.empty());
    }
}
