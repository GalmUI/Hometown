package dev.conner.hometown.network.data;

import dev.conner.hometown.settlement.Settlement;
import dev.conner.hometown.settlement.SettlementStats;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;

public record TownLedgerSnapshot(UUID settlementId, String townName, String founderName, long foundedDay,
        String dimension, BlockPos bell, BellState bellState, SettlementStats.Availability availability,
        int population, int beds, int employed, int professionDiversity, int residentPage, int residentPages,
        List<ResidentSummary> residents, dev.conner.hometown.housing.HousingSnapshot housing, dev.conner.hometown.food.FoodSnapshot food) {
    public TownLedgerSnapshot(UUID id, String name, String founder, long day, String dimension, BlockPos bell,
            BellState bellState, SettlementStats.Availability availability, int population, int beds, int employed,
            int diversity, int page, int pages, List<ResidentSummary> residents) {
        this(id,name,founder,day,dimension,bell,bellState,availability,population,beds,employed,diversity,page,pages,residents,
                dev.conner.hometown.housing.HousingSnapshot.unavailable(population,beds));
    }
    public TownLedgerSnapshot(UUID id, String name, String founder, long day, String dimension, BlockPos bell,
            BellState bellState, SettlementStats.Availability availability, int population, int beds, int employed,
            int diversity, int page, int pages, List<ResidentSummary> residents, dev.conner.hometown.housing.HousingSnapshot housing) {
        this(id,name,founder,day,dimension,bell,bellState,availability,population,beds,employed,diversity,page,pages,residents,
                housing,dev.conner.hometown.food.FoodSnapshot.unavailable(population));
    }
    public TownLedgerSnapshot withFood(dev.conner.hometown.food.FoodSnapshot food) {
        return new TownLedgerSnapshot(settlementId,townName,founderName,foundedDay,dimension,bell,bellState,availability,
                population,beds,employed,professionDiversity,residentPage,residentPages,residents,housing,food);
    }
    public TownLedgerSnapshot withHousing(dev.conner.hometown.housing.HousingSnapshot housing) {
        return new TownLedgerSnapshot(settlementId,townName,founderName,foundedDay,dimension,bell,bellState,availability,
                population,beds,employed,professionDiversity,residentPage,residentPages,residents,housing,food);
    }
    public static final int PAGE_SIZE = 4;
    public enum BellState { PRESENT, MISSING, UNAVAILABLE }
    public TownLedgerSnapshot {
        java.util.Objects.requireNonNull(housing);
        java.util.Objects.requireNonNull(food);
        bell = bell.immutable();
        residents = List.copyOf(residents);
        if (residents.size() > PAGE_SIZE || residentPage < 0 || residentPages < 1 || residentPage >= residentPages)
            throw new IllegalArgumentException("Invalid resident page");
    }

    public static TownLedgerSnapshot of(Settlement town, SettlementStats stats, BellState bellState, int requestedPage) {
        int pages = Math.max(1, (stats.residents().size() + PAGE_SIZE - 1) / PAGE_SIZE);
        int page = Math.max(0, Math.min(requestedPage, pages - 1));
        int start = page * PAGE_SIZE;
        return new TownLedgerSnapshot(town.id(), town.name(), town.founderName(), town.foundedDay(),
                town.dimension().location().toString(), town.bellPosition(), bellState, stats.availability(),
                stats.population(), stats.beds(), stats.employed(), stats.professionDiversity(), page, pages,
                stats.residents().subList(start, Math.min(start + PAGE_SIZE, stats.residents().size())));
    }
}
