package dev.conner.hometown.food;

import dev.conner.hometown.Hometown;
import dev.conner.hometown.settlement.*;
import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.world.Container;
import net.minecraft.world.RandomizableContainer;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.ChestType;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Explicit loaded-block-entity scan. Never opens, unpacks, extracts, or modifies inventories. */
public final class FoodScanner {
    public static final TagKey<Block> FOOD_STORAGE = TagKey.create(Registries.BLOCK, ResourceLocation.fromNamespaceAndPath("hometown","food_storage"));
    public static final TagKey<Item> FOOD_EXCLUDED = TagKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath("hometown","food_excluded"));
    public static final int MAX_BLOCK_ENTITIES = 32768, MAX_STORAGE = 4096, MAX_SLOTS = 131072;
    private FoodScanner() {}
    private record Store(BlockPos pos, BlockState state, BlockEntity entity) {}
    public static FoodSnapshot scan(ServerLevel level, Settlement town, SettlementStats stats, int vertical, FoodRules rules) {
        if (level == null || stats.availability() != SettlementStats.Availability.COMPLETE) return FoodSnapshot.unavailable(stats.population());
        try { return loadedScan(level,town,stats.population(),vertical,rules); }
        catch (RuntimeException exception) {
            Hometown.LOGGER.warn("Unable to inspect Food stores for Hometown [{}]",town.id(),exception);
            return FoodSnapshot.unavailable(stats.population());
        }
    }
    private static FoodSnapshot loadedScan(ServerLevel level, Settlement town, int population, int vertical, FoodRules rules) {
        AABB bounds = SettlementQueries.bounds(town.bellPosition(),town.radius(),vertical);
        var bell = town.bellPosition(); int radius=town.radius(), inspected=0;
        Map<BlockPos,Store> stores = new HashMap<>();
        for (int x=(bell.getX()-radius)>>4; x<=(bell.getX()+radius)>>4; x++) {
            for (int z=(bell.getZ()-radius)>>4; z<=(bell.getZ()+radius)>>4; z++) {
                var chunk=level.getChunkSource().getChunkNow(x,z);
                if (chunk==null) return FoodSnapshot.unavailable(population);
                // Includes pending block entities: tagged storage without available data is incomplete.
                for (BlockPos pos:chunk.getBlockEntitiesPos()) {
                    if (++inspected > MAX_BLOCK_ENTITIES) return FoodSnapshot.unavailable(population);
                    if (!bounds.contains(Vec3.atCenterOf(pos))) continue;
                    BlockState state=chunk.getBlockState(pos);
                    if (!state.is(FOOD_STORAGE)) continue;
                    var entity=chunk.getBlockEntities().get(pos);
                    if (entity==null || entity.isRemoved() || !(entity instanceof Container)
                            || (entity instanceof RandomizableContainer loot && loot.getLootTable()!=null))
                        return FoodSnapshot.unavailable(population);
                    stores.put(pos.immutable(),new Store(pos.immutable(),state,entity));
                    if (stores.size()>MAX_STORAGE) return FoodSnapshot.unavailable(population);
                }
            }
        }
        Set<Container> visited=Collections.newSetFromMap(new IdentityHashMap<>());
        Set<BlockPos> containingFood=new HashSet<>(); Set<Item> types=new HashSet<>();
        int stacks=0, slots=0; long nutrition=0;
        for (Store store:stores.values()) {
            Container inventory=(Container)store.entity();
            if (!visited.add(inventory)) continue;
            int size=inventory.getContainerSize();
            if (size<0 || size>MAX_SLOTS-slots) return FoodSnapshot.unavailable(population);
            slots+=size; boolean food=false;
            for (int slot=0;slot<size;slot++) {
                var stack=inventory.getItem(slot);
                if (stack==null) return FoodSnapshot.unavailable(population);
                if (stack.isEmpty() || stack.is(FOOD_EXCLUDED)) continue;
                var properties=stack.get(DataComponents.FOOD);
                if (properties==null || properties.nutrition()<=0) continue;
                nutrition=Math.addExact(nutrition,Math.multiplyExact((long)properties.nutrition(),stack.getCount()));
                stacks++;types.add(stack.getItem());food=true;
            }
            if (food) containingFood.add(inventoryKey(store,stores));
        }
        return rules.snapshot(population,containingFood.size(),stacks,types.size(),nutrition);
    }
    private static BlockPos inventoryKey(Store store, Map<BlockPos,Store> stores) {
        // Count each vanilla physical half's local 27 slots, never the combined 54-slot wrapper.
        // Pair only halves inside the town: outside storage is never included.
        if (store.entity() instanceof ChestBlockEntity && store.state().getBlock() instanceof ChestBlock
                && store.state().getValue(ChestBlock.TYPE)!=ChestType.SINGLE) {
            BlockPos partnerPos=store.pos().relative(ChestBlock.getConnectedDirection(store.state()));
            Store partner=stores.get(partnerPos);
            if (partner!=null && partner.entity() instanceof ChestBlockEntity && partner.state().is(store.state().getBlock())
                    && partner.state().getValue(ChestBlock.FACING)==store.state().getValue(ChestBlock.FACING)
                    && partner.state().getValue(ChestBlock.TYPE)!=ChestType.SINGLE
                    && partnerPos.relative(ChestBlock.getConnectedDirection(partner.state())).equals(store.pos()))
                return store.pos().compareTo(partnerPos)<0 ? store.pos() : partnerPos;
        }
        return store.pos();
    }
}
