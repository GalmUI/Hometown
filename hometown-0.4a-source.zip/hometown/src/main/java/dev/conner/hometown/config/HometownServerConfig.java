package dev.conner.hometown.config;

import net.neoforged.neoforge.common.ModConfigSpec;

public final class HometownServerConfig {
    public static final ModConfigSpec SPEC;
    public static final ModConfigSpec.IntValue SETTLEMENT_RADIUS;
    public static final ModConfigSpec.IntValue NUTRITION_PER_RESIDENT_PER_DAY;
    public static final ModConfigSpec.IntValue VERTICAL_SCAN_RADIUS;
    public static final ModConfigSpec.IntValue MINIMUM_VILLAGERS;
    public static final ModConfigSpec.IntValue MINIMUM_BEDS;
    public static final ModConfigSpec.BooleanValue PREVENT_OVERLAP;
    public static final ModConfigSpec.BooleanValue CONSUME_BOOK;
    static {
        ModConfigSpec.Builder builder = new ModConfigSpec.Builder();
        SETTLEMENT_RADIUS = builder.comment("Radius stored on new settlements; existing radii never change.")
                .defineInRange("settlementRadius", 64, 16, 256);
        VERTICAL_SCAN_RADIUS = builder.defineInRange("verticalScanRadius", 32, 8, 128);
        MINIMUM_VILLAGERS = builder.defineInRange("minimumVillagers", 2, 0, 100);
        MINIMUM_BEDS = builder.defineInRange("minimumBeds", 2, 0, 100);
        PREVENT_OVERLAP = builder.define("preventSettlementOverlap", true);
        CONSUME_BOOK = builder.define("consumeFoundingBook", true);
        NUTRITION_PER_RESIDENT_PER_DAY = builder.comment("Diagnostic nutrition points per resident per Minecraft day; never consumes items.")
                .defineInRange("nutritionPerResidentPerDay", 20, 1, 1000000);
        SPEC = builder.build();
    }
    private HometownServerConfig() {}
}
