package dev.conner.hometown.food;

import dev.conner.hometown.config.HometownServerConfig;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import static dev.conner.hometown.food.FoodSnapshot.FoodSecurityState.*;

/** All arithmetic runs server-side. Thresholds are isolated for future configuration. */
public record FoodRules(int nutritionPerResidentPerDay, double lowDays, double stableDays, double stockedDays) {
    public static final FoodRules DEFAULT = new FoodRules(20,1,3,7);
    public FoodRules {
        if (nutritionPerResidentPerDay <= 0 || !Double.isFinite(stockedDays) || !(0 < lowDays && lowDays < stableDays && stableDays < stockedDays))
            throw new IllegalArgumentException("Invalid Food rules");
    }
    public static FoodRules current() { return new FoodRules(HometownServerConfig.NUTRITION_PER_RESIDENT_PER_DAY.get(),1,3,7); }
    public FoodSnapshot snapshot(int population, int containers, int stacks, int types, long nutrition) {
        long daily = Math.multiplyExact((long)population, nutritionPerResidentPerDay);
        if (population == 0) return new FoodSnapshot(0,containers,stacks,types,nutrition,daily,OptionalDouble.empty(),NO_RESIDENTS,true,OptionalInt.empty());
        double days = (double)nutrition / daily;
        var state = nutrition == 0 ? EMPTY : days < lowDays ? CRITICAL : days < stableDays ? LOW : days < stockedDays ? STABLE : STOCKED;
        int bar = (int)Math.round(Math.min(100,days / stockedDays * 100));
        return new FoodSnapshot(population,containers,stacks,types,nutrition,daily,OptionalDouble.of(days),state,true,OptionalInt.of(bar));
    }
}
