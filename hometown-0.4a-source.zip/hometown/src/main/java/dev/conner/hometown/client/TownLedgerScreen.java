package dev.conner.hometown.client;

import dev.conner.hometown.network.RequestTownLedgerPayload;
import dev.conner.hometown.network.TownLedgerSnapshotPayload;
import dev.conner.hometown.network.data.TownLedgerSnapshot;
import dev.conner.hometown.settlement.SettlementStats;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.neoforged.neoforge.network.PacketDistributor;

/** Presentation only. All town facts and resident pages arrive from the server. */
public final class TownLedgerScreen extends Screen {
    private static final int BOOK_WIDTH = 384, BOOK_HEIGHT = 224;
    private static final int INK = 0xFF493323, MUTED = 0xFF79654A, WARNING = 0xFF8B3D28;
    private static int nextRequest;
    private final InteractionHand hand;
    private TownLedgerSnapshot snapshot;
    private TownLedgerSnapshotPayload.Error error = TownLedgerSnapshotPayload.Error.NONE;
    private int requestId, requestedPage, activeTab, left, top, bookWidth, bookHeight, waitTicks;
    private boolean waiting;
    private Button previous, next, retry;
    private DevelopmentSection activeDevelopment = DevelopmentSection.HOUSING;
    private final java.util.List<Button> developmentButtons = new java.util.ArrayList<>();
    private Component hoveredText;

    public TownLedgerScreen(InteractionHand hand) {
        super(Component.translatable("item.hometown.town_ledger"));
        this.hand = hand;
    }

    @Override protected void init() {
        // Native GUI pixels. Small viewports change layout bounds, never the pose/font scale.
        bookWidth = Math.min(BOOK_WIDTH, width - 12);
        bookHeight = Math.min(BOOK_HEIGHT, height - 44);
        left = (width - bookWidth) / 2;
        top = (height - bookHeight) / 2;
        int tabWidth = (bookWidth - 12) / 4;
        String[] tabs = {"overview", "residents", "development", "history"};
        for (int i = 0; i < tabs.length; i++) {
            final int tab = i;
            addRenderableWidget(new Bookmark(left + 6 + tabWidth * i, top - 18, tabWidth - 2, 21,
                    Component.translatable("hometown.ledger.tab." + tabs[i]), button -> { activeTab = tab; updateButtons(); }, tab));
        }
        previous = addRenderableWidget(new Bookmark(left + 18, top + bookHeight - 25, 36, 17,
                Component.literal("←"), button -> requestPage(snapshot.residentPage() - 1), -1));
        next = addRenderableWidget(new Bookmark(left + bookWidth - 54, top + bookHeight - 25, 36, 17,
                Component.literal("→"), button -> requestPage(snapshot.residentPage() + 1), -1));
        retry = addRenderableWidget(new Bookmark(left + bookWidth / 2 - 42, top + bookHeight - 25, 84, 17,
                Component.translatable("hometown.ledger.retry"), button -> requestPage(requestedPage), -1));
        developmentButtons.clear();
        int subsectionWidth = (bookWidth - 24) / DevelopmentSection.values().length;
        for (var section : DevelopmentSection.values()) {
            Component label = Component.translatable(section.translationKey());
            var bookmark = new Bookmark(left + 12 + section.ordinal() * subsectionWidth, top + 33,
                    subsectionWidth - 2, 16, label, button -> { activeDevelopment = section; updateButtons(); },
                    () -> activeDevelopment == section);
            bookmark.setTooltip(net.minecraft.client.gui.components.Tooltip.create(label));
            developmentButtons.add(addRenderableWidget(bookmark));
        }
        updateButtons();
    }

    public void requestPage(int page) {
        requestId = ++nextRequest;
        requestedPage = Math.max(0, page);
        waiting = true;
        waitTicks = 0;
        error = TownLedgerSnapshotPayload.Error.NONE;
        updateButtons();
        PacketDistributor.sendToServer(new RequestTownLedgerPayload(hand, requestedPage, requestId));
    }

    public void receive(TownLedgerSnapshotPayload payload) {
        if (payload.requestId() != requestId || !waiting) return;
        waiting = false;
        error = payload.error();
        if (payload.snapshot() != null) snapshot = payload.snapshot();
        // Do not keep showing another town's data after an invalid/switched held item.
        if (error != TownLedgerSnapshotPayload.Error.NONE) snapshot = null;
        updateButtons();
    }

    @Override public void tick() {
        if (waiting && ++waitTicks >= 200) {
            waiting = false;
            error = TownLedgerSnapshotPayload.Error.FAILED;
            snapshot = null;
            updateButtons();
        }
    }

    private void updateButtons() {
        if (previous == null) return;
        boolean paging = activeTab == 1 && snapshot != null && snapshot.residentPages() > 1;
        previous.visible = next.visible = paging;
        previous.active = paging && !waiting && snapshot.residentPage() > 0;
        next.active = paging && !waiting && snapshot.residentPage() + 1 < snapshot.residentPages();
        retry.visible = !waiting && error != TownLedgerSnapshotPayload.Error.NONE;
        developmentButtons.forEach(button -> button.visible = activeTab == 2 && snapshot != null);
    }

    @Override public boolean isPauseScreen() { return false; }

    @Override public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        hoveredText = null;
        // Screen.render invokes renderBackground before rendering the bookmark widgets.
        // Calling it after drawing pages would blur the finished pages a second time.
        super.render(graphics, mouseX, mouseY, partialTick);
        if (hoveredText != null) graphics.renderTooltip(font, hoveredText, mouseX, mouseY);
    }

    @Override public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.renderBackground(graphics, mouseX, mouseY, partialTick);
        drawBook(graphics);
        int half = bookWidth / 2;
        int column = half - 34;
        if (snapshot == null) {
            graphics.drawCenteredString(font, title, left + half, top + 20, INK);
            Component message = waiting ? Component.translatable("hometown.ledger.loading") : errorText();
            graphics.drawWordWrap(font, message, left + 25, top + 58, bookWidth - 50, INK);
        } else {
            line(graphics, Component.literal(snapshot.townName()), left + 18, top + 14, bookWidth - 36, INK, mouseX, mouseY);
            graphics.fill(left + 18, top + 29, left + bookWidth - 18, top + 30, 0xFFBCA27D);
            switch (activeTab) {
                case 0 -> overview(graphics, column, mouseX, mouseY);
                case 1 -> residents(graphics, column, mouseX, mouseY);
                case 2 -> development(graphics, column, mouseX, mouseY);
                case 3 -> history(graphics, column);
                default -> throw new IllegalStateException("Unknown tab");
            }
            if (waiting) graphics.drawCenteredString(font, Component.translatable("hometown.ledger.loading"), left + half, top + bookHeight - 21, MUTED);
        }
    }

    private void drawBook(GuiGraphics g) {
        int right = left + bookWidth, bottom = top + bookHeight, middle = left + bookWidth / 2;
        g.fill(left + 3, top + 5, right + 3, bottom + 5, 0x88000000);
        g.fill(left, top, right, bottom, 0xFF60412A);
        g.fill(left + 3, top + 3, right - 3, bottom - 3, 0xFFBEA17B);
        g.fill(left + 5, top + 4, middle, bottom - 6, 0xFFF2E3BE);
        g.fill(middle, top + 4, right - 5, bottom - 6, 0xFFF6E9CB);
        g.fill(left + 7, bottom - 6, right - 7, bottom - 5, 0xFF907653);
        g.fill(left + 9, bottom - 4, right - 9, bottom - 3, 0xFF907653);
        g.fill(middle - 3, top + 6, middle - 1, bottom - 8, 0xFFDBC79E);
        g.fill(middle - 1, top + 6, middle + 1, bottom - 8, 0xFFB69C73);
        g.fill(middle + 1, top + 6, middle + 4, bottom - 8, 0xFFE6D3AE);
    }

    private void overview(GuiGraphics g, int column, int mx, int my) {
        int x = left + 18, y = top + 40, right = left + bookWidth / 2 + 16;
        line(g, Component.translatable("hometown.ledger.founder", snapshot.founderName()), x, y, column, INK, mx, my);
        line(g, Component.translatable("hometown.ledger.day", snapshot.foundedDay()), x, y + 14, column, MUTED, mx, my);
        line(g, Component.translatable("hometown.ledger.dimension", dimension()), x, y + 38, column, INK, mx, my);
        var bell = snapshot.bell();
        line(g, Component.translatable("hometown.ledger.bell", bell.getX(), bell.getY(), bell.getZ()), x, y + 52, column, INK, mx, my);
        Component warning = switch (snapshot.bellState()) {
            case PRESENT -> Component.empty();
            case MISSING -> Component.translatable("hometown.ledger.bell_missing", bell.getX(), bell.getY(), bell.getZ());
            case UNAVAILABLE -> Component.translatable("hometown.ledger.bell_unavailable");
        };
        g.drawWordWrap(font, warning, x, y + 70, column, WARNING);
        String[] metrics = {"population", "beds", "employed", "professions"};
        int[] values = {snapshot.population(), snapshot.beds(), snapshot.employed(), snapshot.professionDiversity()};
        for (int i = 0; i < metrics.length; i++) {
            Object value = snapshot.availability() == SettlementStats.Availability.UNAVAILABLE ? "—" : values[i];
            line(g, Component.translatable("hometown.ledger.stat." + metrics[i], value), right, y + i * 19, column, INK, mx, my);
        }
        g.drawWordWrap(font, availabilityText(), right, y + 84, column, MUTED);
    }

    private void residents(GuiGraphics g, int column, int mx, int my) {
        if (snapshot.residents().isEmpty()) {
            g.drawWordWrap(font, snapshot.availability() == SettlementStats.Availability.UNAVAILABLE ? availabilityText()
                    : Component.translatable("hometown.ledger.no_residents"), left + 18, top + 48, column, MUTED);
        }
        for (int i = 0; i < snapshot.residents().size(); i++) {
            var resident = snapshot.residents().get(i);
            int x = left + 18 + (i / 2) * (bookWidth / 2);
            int y = top + 43 + (i % 2) * 44;
            Component name = resident.name().isBlank() ? Component.translatable("entity.minecraft.villager") : Component.literal(resident.name());
            line(g, name, x, y, column, INK, mx, my);
            line(g, Component.translatable(resident.professionKey()), x, y + 12, column, MUTED, mx, my);
            line(g, Component.translatable(resident.child() ? "hometown.ledger.child" : "hometown.ledger.adult"), x, y + 24, column, MUTED, mx, my);
        }
        g.drawCenteredString(font, Component.translatable("hometown.ledger.page", snapshot.residentPage() + 1, snapshot.residentPages()),
                left + bookWidth / 2, top + bookHeight - 40, MUTED);
        if (snapshot.availability() == SettlementStats.Availability.PARTIAL)
            line(g, availabilityText(), left + 18, top + bookHeight - 56, bookWidth - 36, WARNING, mx, my);
    }

    private void development(GuiGraphics g, int column, int mx, int my) {
        if (activeDevelopment == DevelopmentSection.FOOD) { food(g,column,mx,my); return; }
        if (activeDevelopment != DevelopmentSection.HOUSING) {
            line(g, Component.translatable(activeDevelopment.translationKey()), left + 18, top + 60, column, INK, mx, my);
            g.drawWordWrap(font, Component.translatable("hometown.development.placeholder"), left + 18, top + 82, column, MUTED);
            return;
        }
        housing(g, column, mx, my);
    }

    private void food(GuiGraphics g, int column, int mx, int my) {
        int x=left+18, right=left+bookWidth/2+18, y=top+58;
        var f=snapshot.food();
        line(g,Component.translatable("hometown.food.security"),x,y,column,INK,mx,my);
        line(g,Component.translatable("hometown.food.stores"),right,y,column,INK,mx,my);
        line(g,Component.translatable("hometown.food.state."+f.state().name().toLowerCase(java.util.Locale.ROOT)),x,y+12,column,
                f.scanComplete()?INK:WARNING,mx,my);
        if (!f.scanComplete()) {
            g.drawWordWrap(font,Component.translatable("hometown.food.unavailable"),x,y+36,column,MUTED);
            return;
        }
        line(g,Component.translatable("hometown.food.reserves"),x,y+28,column,INK,mx,my);
        if (f.barPercent().isPresent()) {
            g.fill(x,y+41,x+column,y+46,0xFFBCA27D);
            int filled=column*f.barPercent().getAsInt()/100;
            if(filled>0)g.fill(x,y+41,x+filled,y+46,0xFF817644);
        }
        Component duration=f.reserveDays().isPresent()?Component.translatable("hometown.food.days",String.format(java.util.Locale.ROOT,"%.1f",f.reserveDays().getAsDouble()))
                :Component.literal("N/A");
        line(g,duration,x,y+52,column,INK,mx,my);
        String[] supplyKeys={"residents","daily","nutrition"};
        long[] supply={f.population(),f.dailyNutritionRequirement(),f.totalNutrition()};
        for(int i=0;i<supplyKeys.length;i++) line(g,Component.translatable("hometown.food."+supplyKeys[i],String.format(java.util.Locale.ROOT,"%,d",supply[i])),
                x,y+76+i*14,column,INK,mx,my);
        String[] storeKeys={"containers","stacks","types","nutrition"};
        long[] stores={f.foodContainers(),f.foodStacks(),f.uniqueFoodTypes(),f.totalNutrition()};
        for(int i=0;i<storeKeys.length;i++) line(g,Component.translatable("hometown.food."+storeKeys[i],String.format(java.util.Locale.ROOT,"%,d",stores[i])),
                right,y+28+i*18,column,INK,mx,my);
    }

    private void housing(GuiGraphics g, int column, int mx, int my) {
        int x = left + 18, right = left + bookWidth / 2 + 18, y = top + 58;
        var h = snapshot.housing();
        line(g, Component.translatable("hometown.housing.supply"), x, y, column, INK, mx, my);
        line(g, Component.translatable("hometown.housing.privacy_title"), right, y, column, INK, mx, my);
        line(g, Component.translatable("hometown.housing.state." + h.state().name().toLowerCase(java.util.Locale.ROOT)),
                x, y + 12, column, h.scanComplete() ? INK : WARNING, mx, my);
        if (!h.scanComplete()) {
            g.drawWordWrap(font, Component.translatable("hometown.housing.unavailable_detail"), x, y + 42, column, MUTED);
            line(g, Component.translatable("hometown.housing.capacity", "N/A"), x, y + 24, column, MUTED, mx, my);
            line(g, Component.translatable("hometown.housing.privacy", "N/A"), right, y + 24, column, MUTED, mx, my);
            return;
        }
        percent(g, "hometown.housing.capacity", h.capacityPercent(), x, y + 24, column, mx, my);
        percent(g, "hometown.housing.privacy", h.privacyPercent(), right, y + 24, column, mx, my);
        String[] supplyKeys = {"residents", "enclosed", "unhoused", "spare", "total", "unsealed"};
        int[] supply = {h.population(),h.enclosedBeds(),h.unhousedResidents(),h.spareHousingCapacity(),h.totalBeds(),h.unsealedBeds()};
        String[] roomKeys = {"rooms", "private", "shared", "crowded", "high_density"};
        int[] rooms = {h.roomCount(),h.privateRooms(),h.sharedRooms(),h.crowdedRooms(),h.highDensityRooms()};
        for (int i=0; i<supplyKeys.length; i++) line(g, Component.translatable("hometown.housing." + supplyKeys[i], supply[i]),
                x, y + 48 + i * 12, column, INK, mx, my);
        for (int i=0; i<roomKeys.length; i++) line(g, Component.translatable("hometown.housing." + roomKeys[i], rooms[i]),
                right, y + 48 + i * 12, column, INK, mx, my);
    }

    private void percent(GuiGraphics g, String key, java.util.OptionalInt value, int x, int y, int width, int mx, int my) {
        line(g, Component.translatable(key, value.isPresent() ? value.getAsInt() + "%" : "N/A"), x, y, width, INK, mx, my);
        if (value.isEmpty()) return;
        g.fill(x, y + 11, x + width, y + 16, 0xFFBCA27D);
        int filled = width * Math.clamp(value.getAsInt(), 0, 100) / 100;
        if (filled > 0) g.fill(x, y + 11, x + filled, y + 16, 0xFF817644);
    }

    private void history(GuiGraphics g, int column) {
        g.drawString(font, Component.translatable("hometown.ledger.history_day", snapshot.foundedDay()), left + 18, top + 43, MUTED, false);
        g.drawWordWrap(font, Component.translatable("hometown.ledger.founding_event", snapshot.townName(), snapshot.founderName()),
                left + 18, top + 64, column, INK);
    }

    private Component dimension() {
        return switch (snapshot.dimension()) {
            case "minecraft:overworld" -> Component.translatable("hometown.dimension.overworld");
            case "minecraft:the_nether" -> Component.translatable("hometown.dimension.nether");
            case "minecraft:the_end" -> Component.translatable("hometown.dimension.end");
            default -> Component.literal(snapshot.dimension());
        };
    }
    private Component availabilityText() {
        return Component.translatable(switch (snapshot.availability()) {
            case COMPLETE -> "hometown.ledger.fresh";
            case PARTIAL -> "hometown.ledger.partial";
            case UNAVAILABLE -> "hometown.ledger.unavailable";
        });
    }
    private Component errorText() {
        return Component.translatable(switch (error) {
            case UNKNOWN -> "hometown.ledger.unknown";
            case HOLD_LEDGER -> "hometown.ledger.hold";
            case WAIT -> "hometown.ledger.wait";
            default -> "hometown.ledger.failed";
        });
    }

    private void line(GuiGraphics g, Component text, int x, int y, int maxWidth, int color, int mx, int my) {
        String value = text.getString();
        boolean shortened = font.width(value) > maxWidth;
        String shown = shortened ? font.plainSubstrByWidth(value, Math.max(0, maxWidth - font.width("…"))) + "…" : value;
        g.drawString(font, shown, x, y, color, false);
        if (shortened && mx >= x && mx < x + maxWidth && my >= y && my < y + 11) hoveredText = text;
    }

    private final class Bookmark extends Button {
        private final java.util.function.BooleanSupplier selection;
        private Bookmark(int x, int y, int w, int h, Component label, OnPress press, int tab) {
            this(x, y, w, h, label, press, () -> tab >= 0 && tab == activeTab);
        }
        private Bookmark(int x, int y, int w, int h, Component label, OnPress press, java.util.function.BooleanSupplier selection) {
            super(x, y, w, h, label, press, DEFAULT_NARRATION);
            this.selection = selection;
        }
        @Override protected void renderWidget(GuiGraphics g, int mx, int my, float tick) {
            boolean selected = selection.getAsBoolean();
            int edge = isHoveredOrFocused() ? 0xFF8C4632 : 0xFF927652;
            g.fill(getX(), getY(), getX() + getWidth(), getY() + getHeight(), edge);
            g.fill(getX() + 1, getY() + 1, getX() + getWidth() - 1, getY() + getHeight() - 1,
                    selected ? 0xFFF6E9CB : 0xFFD8BF93);
            if (selected) g.fill(getX() + 5, getY() + getHeight() - 4, getX() + getWidth() - 5, getY() + getHeight() - 3, 0xFF99513B);
            String label = font.plainSubstrByWidth(getMessage().getString(), getWidth() - 6);
            g.drawString(font, label, getX() + (getWidth() - font.width(label)) / 2, getY() + (getHeight() - 8) / 2,
                    active ? INK : MUTED, false);
        }
    }
}
