package dev.conner.hometown.network;

import dev.conner.hometown.Hometown;
import dev.conner.hometown.network.data.ResidentSummary;
import dev.conner.hometown.network.data.TownLedgerSnapshot;
import dev.conner.hometown.settlement.SettlementStats;
import java.util.ArrayList;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

public record TownLedgerSnapshotPayload(int requestId, TownLedgerSnapshot snapshot, Error error) implements CustomPacketPayload {
    public enum Error { NONE, UNKNOWN, HOLD_LEDGER, WAIT, FAILED }
    public static final Type<TownLedgerSnapshotPayload> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(Hometown.MOD_ID, "ledger_snapshot"));
    public static final StreamCodec<FriendlyByteBuf, TownLedgerSnapshotPayload> STREAM_CODEC = StreamCodec.of(
            TownLedgerSnapshotPayload::write, TownLedgerSnapshotPayload::read);
    public TownLedgerSnapshotPayload {
        if ((error == Error.NONE) != (snapshot != null)) throw new IllegalArgumentException("Invalid ledger response");
    }
    private static void write(FriendlyByteBuf b, TownLedgerSnapshotPayload p) {
        b.writeInt(p.requestId()); b.writeEnum(p.error());
        if (p.error() != Error.NONE) return;
        var s = p.snapshot();
        b.writeUUID(s.settlementId()); b.writeUtf(s.townName(), 64); b.writeUtf(s.founderName(), 256);
        b.writeLong(s.foundedDay()); b.writeUtf(s.dimension(), 256); b.writeBlockPos(s.bell());
        b.writeEnum(s.bellState()); b.writeEnum(s.availability());
        b.writeVarInt(s.population()); b.writeVarInt(s.beds()); b.writeVarInt(s.employed()); b.writeVarInt(s.professionDiversity());
        var h = s.housing();
        for (int value : new int[]{h.population(), h.totalBeds(), h.enclosedBeds(), h.unsealedBeds(), h.roomCount(), h.privateRooms(), h.sharedRooms(), h.sharedBeds(), h.unknownBeds()}) b.writeVarInt(value);
        b.writeBoolean(h.scanComplete());
        b.writeVarInt(s.residentPage()); b.writeVarInt(s.residentPages()); b.writeVarInt(s.residents().size());
        for (var r : s.residents()) {
            b.writeUtf(r.name(), ResidentSummary.MAX_TEXT); b.writeUtf(r.professionKey(), ResidentSummary.MAX_TEXT); b.writeBoolean(r.child());
        }
    }
    private static TownLedgerSnapshotPayload read(FriendlyByteBuf b) {
        int request = b.readInt();
        Error error = b.readEnum(Error.class);
        if (error != Error.NONE) return new TownLedgerSnapshotPayload(request, null, error);
        var id = b.readUUID(); var name = b.readUtf(64); var founder = b.readUtf(256);
        long day = b.readLong(); var dimension = b.readUtf(256); var bell = b.readBlockPos();
        var bellState = b.readEnum(TownLedgerSnapshot.BellState.class); var availability = b.readEnum(SettlementStats.Availability.class);
        int population = b.readVarInt(), beds = b.readVarInt(), employed = b.readVarInt(), diversity = b.readVarInt();
        var housing = new dev.conner.hometown.housing.HousingSnapshot(b.readVarInt(), b.readVarInt(), b.readVarInt(), b.readVarInt(), b.readVarInt(), b.readVarInt(), b.readVarInt(), b.readVarInt(), b.readVarInt(), b.readBoolean());
        int page = b.readVarInt(), pages = b.readVarInt(), count = b.readVarInt();
        if (count < 0 || count > TownLedgerSnapshot.PAGE_SIZE) throw new IllegalArgumentException("Resident page too large");
        var residents = new ArrayList<ResidentSummary>(count);
        for (int i = 0; i < count; i++) residents.add(new ResidentSummary(b.readUtf(ResidentSummary.MAX_TEXT), b.readUtf(ResidentSummary.MAX_TEXT), b.readBoolean()));
        return new TownLedgerSnapshotPayload(request, new TownLedgerSnapshot(id, name, founder, day, dimension, bell,
                bellState, availability, population, beds, employed, diversity, page, pages, residents, housing), Error.NONE);
    }
    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
