package dev.conner.hometown.housing;

import java.util.OptionalInt;

/** Derived counts only. When incomplete, observations are partial and capacity is unavailable. */
public record HousingSnapshot(int population, int totalBeds, int enclosedBeds, int unsealedBeds,
        int roomCount, int privateRooms, int sharedRooms, int sharedBeds, int unknownBeds, boolean scanComplete) {
    public enum HousingCapacityState { NO_RESIDENTS, OVERCROWDED, SUFFICIENT, SCAN_INCOMPLETE }
    public HousingSnapshot {
        if (population < 0 || totalBeds < 0 || enclosedBeds < 0 || unsealedBeds < 0 || roomCount < 0
                || privateRooms < 0 || sharedRooms < 0 || sharedBeds < 0 || unknownBeds < 0
                || (long)enclosedBeds + unsealedBeds + unknownBeds != totalBeds
                || (long)privateRooms + sharedRooms != roomCount || sharedBeds > enclosedBeds
                || (scanComplete && unknownBeds != 0)) throw new IllegalArgumentException("Invalid Housing counts");
    }
    public static HousingSnapshot unavailable(int population, int beds) {
        return new HousingSnapshot(population, beds, 0, 0, 0, 0, 0, 0, beds, false);
    }
    public OptionalInt capacityPercent() {
        return !scanComplete || population == 0 ? OptionalInt.empty()
                : OptionalInt.of((int)Math.min(100, ((long)enclosedBeds * 100 + population / 2) / population));
    }
    public int unhousedResidents() { return scanComplete ? Math.max(0, population - enclosedBeds) : 0; }
    public int spareHousingCapacity() { return scanComplete ? Math.max(0, enclosedBeds - population) : 0; }
    public HousingCapacityState state() {
        return !scanComplete ? HousingCapacityState.SCAN_INCOMPLETE : population == 0 ? HousingCapacityState.NO_RESIDENTS
                : population > enclosedBeds ? HousingCapacityState.OVERCROWDED : HousingCapacityState.SUFFICIENT;
    }
}
