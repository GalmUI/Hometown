package dev.conner.hometown.housing;

import dev.conner.hometown.room.*;
import dev.conner.hometown.settlement.*;
import java.util.*;
import java.util.function.Function;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;

/** Explicit synchronous Ledger scan only. No persistence or background work. */
public final class HousingScanner {
    public static final int MAX_ROOM_ATTEMPTS = 32;
    public static final int MAX_BEDS = 4096;
    private HousingScanner() {}
    public static HousingSnapshot scan(ServerLevel level, Settlement town, SettlementStats stats, int vertical) {
        if (level == null || stats.availability() != SettlementStats.Availability.COMPLETE)
            return HousingSnapshot.unavailable(stats.population(), stats.beds());
        var bedScan = SettlementQueries.scanBeds(level, town.bellPosition(), town.radius(), vertical, MAX_BEDS + 1);
        var beds = bedScan.positions();
        if (!bedScan.complete() || beds.size() > MAX_BEDS || beds.size() != stats.beds()) return HousingSnapshot.unavailable(stats.population(), stats.beds());
        RoomDetector detector = new RoomDetector(new LoadedRoomWorld(level));
        return aggregate(stats.population(), beds, detector::detect);
    }
    public static HousingSnapshot aggregate(int population, Collection<BlockPos> positions,
                                             Function<BlockPos, RoomDetectionResult> detect) {
        var beds = positions.stream().map(BlockPos::immutable).distinct().sorted().toList();
        if (beds.size() > MAX_BEDS) return HousingSnapshot.unavailable(population, beds.size());
        Map<BlockPos, RoomDetectionResult> known = new HashMap<>();
        Map<BlockPos, RoomDetectionResult> failures = new HashMap<>();
        int attempts = 0;
        for (BlockPos bed : beds) {
            if (known.containsKey(bed) || attempts >= MAX_ROOM_ATTEMPTS) continue;
            attempts++;
            var room = detect.apply(bed);
            if (room.enclosed()) for (BlockPos member : room.bedPositions()) known.put(member, room);
            else failures.put(bed, room);
        }
        // A later seed may prove enclosure after an earlier distance-limited attempt.
        // Classify only after collecting successes so all relevant members receive that result.
        Set<BlockPos> rooms = new HashSet<>();
        int enclosed=0, unsealed=0, unknown=0, privateRooms=0, sharedRooms=0, sharedBeds=0;
        for (BlockPos bed : beds) {
            var room = known.get(bed);
            if (room != null) {
                enclosed++;
                boolean shared = room.bedCount() > 1;
                if (shared) sharedBeds++;
                if (rooms.add(room.representativePosition())) { if (shared) sharedRooms++; else privateRooms++; }
            } else {
                var failure = failures.get(bed);
                if (failure == null || failure.failureReason() == RoomFailureReason.CHUNK_UNAVAILABLE
                        || failure.failureReason() == RoomFailureReason.SCAN_BUDGET_EXCEEDED) unknown++;
                else unsealed++;
            }
        }
        return new HousingSnapshot(population, beds.size(), enclosed, unsealed, rooms.size(), privateRooms,
                sharedRooms, sharedBeds, unknown, unknown == 0);
    }
}
