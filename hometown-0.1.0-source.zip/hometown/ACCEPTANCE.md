# In-game acceptance checklist

These checks are **pending manual execution**. Automated tests do not replace a client launch, actual server restart, or a two-client playtest.

Use Minecraft 1.21.1, NeoForge 21.1.250, Java 21, and only Hometown. Test both an integrated world and a dedicated server. Record the mod JAR checksum, NeoForge version, and results when completing this list.

## Founding and cancellation

- [ ] A Book in the main hand, crouching, and a right-click on a Bell with two villagers/two beds opens **Found a Hometown**.
- [ ] `Oakridge` creates one settlement, consumes exactly one Survival Book, delivers one Ledger, rings the Bell, and displays the success message.
- [ ] Cancel and Escape create nothing and consume nothing. Resize the window while typing and confirm the name is preserved.
- [ ] Normal Bell interactions remain unchanged without crouching, with an empty hand, with an off-hand-only Book, and with a Book and Quill, Written Book, or Enchanted Book.
- [ ] One villager fails with the correct count. A baby counts. A Wandering Trader and Zombie Villager do not.
- [ ] One bed fails with the correct count. Unclaimed intact beds count. Destroyed beds, wrong POIs, and beds outside the scan bounds do not.

## Names and authority

- [ ] Leading/trailing spaces trim; punctuation and Unicode names work. Empty, over-32-character, control-character, and formatting-code names fail.
- [ ] `Oakridge` and `oakridge` conflict, including across dimensions.
- [ ] While the screen is open, break the Bell, remove beds, move villagers, remove the Book, move more than eight blocks away, or change dimension; each submission fails without charging.
- [ ] A naming screen left open for over two minutes expires safely.
- [ ] Two players open the same Bell and submit different names: exactly one town and one charge result. Repeat with neighboring Bells and with the same name.
- [ ] Repeated/forged submission packets cannot create a town without a matching server-issued interaction; wrong attempt tokens and oversized strings are rejected.

## Persistence — release gate

Record the settlement UUID from `/hometown debug list` or `inspect` before each check.

- [ ] Quit to title and reload: the same UUID, name, founder, radius, and Bell remain; the original Ledger resolves.
- [ ] Close Minecraft completely, relaunch, and reload: the same data and original Ledger resolve.
- [ ] Stop a dedicated server normally, restart it, and reconnect: the same data and original Ledger resolve.
- [ ] Copy the complete stopped world save and load the copy: the UUID is unchanged and the Ledger resolves.
- [ ] Create two separated towns and repeat the above; both persist independently.
- [ ] Remove a town with the debug command, save/restart, and confirm it remains removed and its old Ledger reports an unknown town.

## Anchors, overlap, and dimensions

- [ ] The same Bell cannot found a second town.
- [ ] Anchors less than 128 horizontal blocks apart conflict with default radii; exactly 128 blocks apart work if village requirements pass.
- [ ] Large vertical separation does not evade overlap. Matching X/Z in different dimensions is allowed with different names.
- [ ] Break a founding Bell and save/restart: the town persists, and its Ledger reports the saved coordinates and missing anchor when loaded.
- [ ] Replace a vanilla Bell at the saved position: the town is still associated with that anchor.
- [ ] Change `settlementRadius` and restart: existing records keep their old radii; new towns use the new default.

## Ledgers, settings, and idle behavior

- [ ] Full Survival inventory drops the Ledger at the player. Repeat in Creative: the Ledger also drops and the Book remains.
- [ ] Creative with space receives a Ledger and retains the Book.
- [ ] A replacement Ledger from the debug command has the correct UUID, display name, and founder/day lore.
- [ ] Ledger use displays only identity, founder, anchor, and dimension; no management screen or future statistics appear.
- [ ] With `consumeFoundingBook=false`, a Book is required but retained. With overlap prevention disabled, duplicate anchors/names still fail.
- [ ] Non-operators cannot use any debug command; operators can list, inspect, remove, and recover a Ledger.
- [ ] No continuous scans/log spam occur while idle. Use a Ledger for a distant unloaded anchor and confirm its chunks stay unloaded.

Version 0.1 should be marked ready only after these checks pass.
