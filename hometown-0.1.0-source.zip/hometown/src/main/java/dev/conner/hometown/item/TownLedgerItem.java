package dev.conner.hometown.item;

import dev.conner.hometown.component.HometownDataComponents;
import dev.conner.hometown.component.SettlementIdComponent;
import dev.conner.hometown.settlement.HometownSavedData;
import dev.conner.hometown.settlement.Settlement;
import dev.conner.hometown.settlement.SettlementValidator;
import java.util.List;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;

public final class TownLedgerItem extends Item {
    public TownLedgerItem(Properties properties) { super(properties); }

    public static ItemStack create(Settlement settlement) {
        ItemStack stack = new ItemStack(HometownItems.TOWN_LEDGER.get());
        stack.set(HometownDataComponents.SETTLEMENT_ID.get(), new SettlementIdComponent(settlement.id()));
        stack.set(DataComponents.CUSTOM_NAME, Component.translatable("item.hometown.town_ledger.named", settlement.name()));
        stack.set(DataComponents.LORE, new ItemLore(List.of(
                Component.translatable("hometown.ledger.founder", settlement.founderName()),
                Component.translatable("hometown.ledger.day", settlement.foundedDay()))));
        return stack;
    }

    public static boolean deliver(ServerPlayer player, ItemStack stack) {
        // Inventory.add may discard an overflow stack in Creative and report success.
        // A non-stackable ledger can only occupy an empty main-inventory slot.
        int slot = player.getInventory().getFreeSlot();
        if (slot >= 0) {
            player.getInventory().setItem(slot, stack.copy());
            player.getInventory().setChanged();
            stack.setCount(0);
            return true;
        }
        // Explicit addFreshEntity return value lets founding roll back if the drop is rejected.
        ItemEntity entity = new ItemEntity(player.serverLevel(), player.getX(), player.getY() + 0.5, player.getZ(), stack.copy(), 0, 0.1, 0);
        entity.setDefaultPickUpDelay();
        entity.setTarget(player.getUUID());
        boolean delivered = player.serverLevel().addFreshEntity(entity);
        if (delivered) stack.setCount(0);
        return delivered;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player instanceof ServerPlayer serverPlayer) {
            SettlementIdComponent id = stack.get(HometownDataComponents.SETTLEMENT_ID.get());
            Settlement town = id == null ? null : HometownSavedData.get(serverPlayer.server).getSettlement(id.settlementId()).orElse(null);
            if (town == null) {
                player.sendSystemMessage(Component.translatable("hometown.ledger.unknown"));
            } else {
                var pos = town.bellPosition();
                player.sendSystemMessage(Component.literal(town.name())
                        .append("\n").append(Component.translatable("hometown.ledger.founder", town.founderName()))
                        .append("\n").append(Component.translatable("hometown.ledger.bell", pos.getX(), pos.getY(), pos.getZ()))
                        .append("\n").append(Component.translatable("hometown.ledger.dimension", dimensionName(town.dimension()))));
                ServerLevel anchorLevel = serverPlayer.server.getLevel(town.dimension());
                if (anchorLevel != null && SettlementValidator.loaded(anchorLevel, pos)
                        && !anchorLevel.getBlockState(pos).is(Blocks.BELL)) {
                    player.sendSystemMessage(Component.translatable("hometown.ledger.anchor_missing"));
                }
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    private static Component dimensionName(ResourceKey<Level> dimension) {
        if (dimension.equals(Level.OVERWORLD)) return Component.translatable("hometown.dimension.overworld");
        if (dimension.equals(Level.NETHER)) return Component.translatable("hometown.dimension.nether");
        if (dimension.equals(Level.END)) return Component.translatable("hometown.dimension.end");
        return Component.literal(dimension.location().toString());
    }
}
