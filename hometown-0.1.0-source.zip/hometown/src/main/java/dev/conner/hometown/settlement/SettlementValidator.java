package dev.conner.hometown.settlement;

import dev.conner.hometown.config.HometownServerConfig;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.village.poi.PoiManager;
import net.minecraft.world.entity.ai.village.poi.PoiTypes;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public final class SettlementValidator {
    private SettlementValidator() {}

    public record Rules(int radius, int verticalRadius, int villagers, int beds, boolean preventOverlap, boolean consumeBook) {
        public static Rules current() {
            return new Rules(HometownServerConfig.SETTLEMENT_RADIUS.get(), HometownServerConfig.VERTICAL_SCAN_RADIUS.get(),
                    HometownServerConfig.MINIMUM_VILLAGERS.get(), HometownServerConfig.MINIMUM_BEDS.get(),
                    HometownServerConfig.PREVENT_OVERLAP.get(), HometownServerConfig.CONSUME_BOOK.get());
        }
    }

    public static Optional<Component> validate(ServerPlayer player, BlockPos bell, HometownSavedData data, Rules rules) {
        ServerLevel level = player.serverLevel();
        if (!player.isAlive() || player.isSpectator()) return error("player");
        if (player.distanceToSqr(Vec3.atCenterOf(bell)) > 64.0) return error("distance");
        if (!loaded(level, bell) || !level.getBlockState(bell).is(Blocks.BELL)) return error("bell_missing");
        if (findBookSlot(player) == -1) return error("book");
        Optional<Settlement> existing = data.findByBell(level.dimension(), bell);
        if (existing.isPresent()) return Optional.of(Component.translatable("hometown.error.existing", existing.get().name()));
        if (rules.preventOverlap() && data.getSettlementsInDimension(level.dimension()).stream()
                .anyMatch(s -> s.overlaps(level.dimension(), bell, rules.radius()))) return error("overlap");

        int radius = rules.radius();
        int vertical = rules.verticalRadius();
        // A box centered on the bell, with inclusive block coordinates at both edges.
        AABB bounds = new AABB(bell).inflate(radius, vertical, radius);
        if (rules.villagers() > 0) {
            int villagers = level.getEntitiesOfClass(Villager.class, bounds,
                    v -> v.getType() == EntityType.VILLAGER && v.isAlive()
                            && bounds.contains(v.position()) && loaded(level, v.blockPosition())).size();
            if (villagers < rules.villagers()) return Optional.of(Component.translatable(
                    "hometown.error.residents", rules.villagers(), villagers));
        }
        if (rules.beds() > 0) {
            int beds = 0;
            int minX = (bell.getX() - radius) >> 4;
            int maxX = (bell.getX() + radius) >> 4;
            int minZ = (bell.getZ() - radius) >> 4;
            int maxZ = (bell.getZ() + radius) >> 4;
            for (int x = minX; x <= maxX; x++) {
                for (int z = minZ; z <= maxZ; z++) {
                    // Do not call getChunk(), ensureLoadedAndValid(), or a range POI lookup:
                    // those can load chunks/POIs outside the already-loaded world state.
                    if (level.getChunkSource().getChunkNow(x, z) == null) continue;
                    try (var records = level.getPoiManager().getInChunk(type -> type.is(PoiTypes.HOME),
                            new net.minecraft.world.level.ChunkPos(x, z), PoiManager.Occupancy.ANY)) {
                        beds += (int)records.filter(p -> bounds.contains(Vec3.atCenterOf(p.getPos()))
                                && validBed(level, p.getPos())).limit(rules.beds() - beds).count();
                    }
                    if (beds >= rules.beds()) break;
                }
                if (beds >= rules.beds()) break;
            }
            if (beds < rules.beds()) return Optional.of(Component.translatable("hometown.error.beds", rules.beds(), beds));
        }
        return Optional.empty();
    }

    private static boolean validBed(ServerLevel level, BlockPos pos) {
        if (!loaded(level, pos)) return false;
        BlockState head = level.getBlockState(pos);
        if (!(head.getBlock() instanceof BedBlock) || head.getValue(BedBlock.PART) != BedPart.HEAD
                || !BuiltInRegistries.BLOCK.getKey(head.getBlock()).getNamespace().equals("minecraft")) return false;
        BlockPos footPos = pos.relative(head.getValue(BedBlock.FACING).getOpposite());
        if (!loaded(level, footPos)) return false;
        BlockState foot = level.getBlockState(footPos);
        return foot.is(head.getBlock()) && foot.getValue(BedBlock.PART) == BedPart.FOOT
                && foot.getValue(BedBlock.FACING) == head.getValue(BedBlock.FACING);
    }

    public static boolean loaded(ServerLevel level, BlockPos pos) {
        return level.getChunkSource().getChunkNow(pos.getX() >> 4, pos.getZ() >> 4) != null;
    }

    /** Inventory includes the off hand. Prefer main hand when it still holds the founding book. */
    public static int findBookSlot(ServerPlayer player) {
        int selected = player.getInventory().selected;
        if (player.getInventory().getItem(selected).is(Items.BOOK)) return selected;
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            if (player.getInventory().getItem(i).is(Items.BOOK)) return i;
        }
        return -1;
    }

    private static Optional<Component> error(String key) {
        return Optional.of(Component.translatable("hometown.error." + key));
    }
}
