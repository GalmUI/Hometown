# Validation record

## Results

- **18 main Java source files compiled** against official Minecraft 1.21.1 mappings and NeoForge 21.1.250 libraries using Java 21.
- **27 JUnit tests passed; zero failures or skipped tests.** The test sources are included under `src/test/java`.
- The preview JAR contains only Hometown classes and resources. Minecraft, NeoForge, Mockito, JUnit, and development libraries are not bundled.

| Test class | Tests | Coverage |
| --- | ---: | --- |
| `TownNamesTest` | 4 | Unicode whitespace, character limits, invalid controls/formatting/surrogates, locale-independent name keys |
| `SettlementPersistenceTest` | 4 | Minecraft SavedData disk writer, compressed NBT reloads and copy, all record fields/UUIDs, dirty tracking, uniqueness, stored radii and horizontal geometry |
| `SettlementValidatorTest` | 4 | Book/Bell/distance checks, living adult/baby villagers, scan boundaries, intact beds/HOME POIs, skipping unloaded chunks, overlap configuration |
| `SettlementManagerTest` | 10 | Server naming attempts, final revalidation, save-wide names, competing submissions, replay/forgery rejection, item transaction order, failed delivery rollback, Creative and configuration behavior |
| `LedgerAndPayloadTest` | 5 | UUID codec persistence, network round trips and payload limits, empty-slot delivery, full Creative inventory drop, rejected drop preservation |

Persistence testing uses Minecraft's `SavedData.save(File, HolderLookup.Provider)` to write the actual compressed world-data wrapper, loads the record data back, repeats the write/read cycle, and copies the file before loading it again. Both town UUIDs and every stored record field are asserted unchanged.

World/entity behavior is tested with mocked server objects and actual mapped Minecraft data types. The competing-player test serializes two pending attempts through the real manager, matching server-thread processing. This is not a two-client network session.

## Build-environment limitation

`gradlew.bat build` did **not** finish in this Windows environment. Dependency downloads succeeded, but NeoForge's `extractServer` task failed in JDK `ZipFileSystem.close` while resolving the parent Documents path (`AccessDeniedException`). Read-access grants did not resolve that metadata lookup, and write permission for a separate temporary build folder was not granted.

For the verification above, the already downloaded official client classes were mapped using NeoForge's AutoRenamingTool. Stale upstream signature metadata was omitted from that transformed development-only input. A short-lived JavaCompiler API harness compiled the Hometown sources; its input archives are released by process exit to avoid the environment's failing archive-close metadata operation. JUnit was then run directly with the mapped classes and required libraries.

The preview JAR was packaged directly from those compiled Hometown classes and the project's resource files. **It is a testing candidate, not a Gradle-produced or in-game-certified release.** The source project's normal Gradle wrapper and build configuration are provided for building in a standard Java 21 development environment.

## Still required before marking v0.1 ready

- A successful standard Gradle build and test run.
- Actual NeoForge client and dedicated-server startup, including client-only class isolation and registry setup.
- Visual confirmation of the naming screen, actual Bell interaction/ringing, and real item delivery.
- Quit/relaunch/reload and copied-world checks inside Minecraft with the original Ledger.
- Two connected players testing the same Bell, neighboring Bells, and duplicate names.
- The remaining cases in [ACCEPTANCE.md](ACCEPTANCE.md).

No in-game acceptance check is represented as completed by this validation record.
