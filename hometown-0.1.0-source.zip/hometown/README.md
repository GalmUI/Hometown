# Hometown v0.1 — Founding Foundation

A standalone Minecraft **1.21.1**, **NeoForge 21.1.250**, **Java 21** mod. Mod ID: `hometown`; package: `dev.conner.hometown`.

**Book in main hand + crouch + right-click Bell → village checks → name → persistent settlement + Town Ledger.**

This implementation contains identity, founding, and persistence only. There are no progression systems, claims, resident tracking, integrations, or background scanners.

## Status

Implementation and automated regression coverage are included. A separately packaged **preview JAR** is provided for in-game testing. It has not been launched in Minecraft here and is **not yet acceptance-certified v0.1**.

The standard Gradle build could not complete in this environment: Windows denied a parent-directory metadata lookup during NeoForge's Minecraft extraction. The sources were instead compiled with Java 21 against the official mapped Minecraft 1.21.1 classes and NeoForge 21.1.250 libraries, and the JUnit suite was run directly. See [VALIDATION.md](VALIDATION.md) for the precise verification boundary and [ACCEPTANCE.md](ACCEPTANCE.md) for the remaining playtests.

## Build and run

Open this directory with a Java 21 JDK configured. The Gradle wrapper is included; its first run downloads the development dependencies.

```powershell
.\gradlew.bat build
.\gradlew.bat runClient
```

On macOS/Linux, use `bash ./gradlew build` and `bash ./gradlew runClient`.

A normal successful build writes `build/libs/hometown-0.1.0.jar`. Put the mod JAR in the `mods` folder on **both the client and the server** of a Minecraft 1.21.1 / NeoForge 21.1.250 instance. Only Minecraft and NeoForge are runtime dependencies.

For a development dedicated server:

```powershell
.\gradlew.bat runServer
```

Follow the server's normal EULA setup if prompted. Run automated tests with `gradlew.bat test`.

## Founding a town

1. Find or build a loaded village area with a vanilla Bell, two living vanilla villagers, and two intact vanilla beds.
2. Hold a plain vanilla Book in your **main hand**, crouch, and right-click the Bell.
3. Enter a name and select **Found Hometown**. Cancel or Escape closes the screen without submitting.
4. On success, the settlement is recorded, a non-stackable Town Ledger is delivered, one Book is consumed in Survival, the Bell rings, and a message appears. Creative keeps the Book.

Names are trimmed, limited to 1–32 Unicode code points, and unique across the save without regard to case. Control characters, malformed Unicode, and `§` are rejected. A failed submission reports its reason in chat; interact with the Bell again to retry.

The server remembers a Bell interaction for up to two minutes. Submission must match that server-issued attempt and dimension, be within eight blocks of the Bell's center, and pass all founding checks again. A plain Book must still exist in the player's inventory; main hand is preferred, but it can have been moved to another inventory slot or the off hand.

The Ledger resolves its UUID on the server and reports the town, founder, saved Bell coordinates, and dimension. An unknown UUID reports an invalid ledger. A missing Bell is reported when its chunk is loaded; reading the Ledger never loads that chunk.

## Storage and geometry

- The overworld's `data/hometown_settlements.dat` stores every town in the save, including other dimensions. Copy the **whole world save** to carry the towns and inventory ledgers with it.
- Settlement records are immutable and keyed by UUID. Adds and removals mark the SavedData dirty. Normal Minecraft saving writes the data; no special export is needed.
- Each record stores its founding radius, founder UUID/name, dimension, anchor, and overworld game time. Day is `foundedGameTime / 24000`.
- Village scans use the box of block positions within ±64 X/Z and ±32 Y by default, counting only loaded world state. Adult and baby vanilla villagers count; dead villagers and other entity types do not.
- Housing uses HOME POIs with any occupancy, checked against intact vanilla bed head/foot blocks. Unclaimed beds count. Neighboring unloaded chunks are skipped.
- Overlap and `findSettlementContaining` use horizontal circular distance. Vertical separation never bypasses overlap. Default anchors exactly 128 blocks apart are allowed. Different dimensions do not conflict.
- Changing the default radius changes only newly founded towns. Breaking an anchor never removes its record. Replacing a vanilla Bell at the exact saved location restores the anchor.
- No tick scanner, chunk tickets, or continuous world scan is registered.

## Server configuration

Minecraft creates `serverconfig/hometown-server.toml` inside the world save. To set defaults for new worlds, use NeoForge's normal `defaultconfigs` workflow.

| Setting | Default | Range |
| --- | --- | --- |
| `settlementRadius` | 64 | 16–256 |
| `verticalScanRadius` | 32 | 8–128 |
| `minimumVillagers` | 2 | 0–100 |
| `minimumBeds` | 2 | 0–100 |
| `preventSettlementOverlap` | true | boolean |
| `consumeFoundingBook` | true | boolean |

Turning off consumption still requires a Book for founding. Turning off overlap still forbids duplicate names and duplicate anchor positions.

## Admin commands

All require operator/cheat permission level 2. There is no town-creation command.

```text
/hometown debug list
/hometown debug inspect <uuid>
/hometown debug remove <uuid>
/hometown debug ledger <uuid>
```

`inspect` displays the serialized record. `remove` deletes it persistently and leaves old ledgers unresolved. `ledger` gives the executing player a replacement, or drops it if their inventory is full. Founder information grants no ownership permissions.

## Implementation map

| Package | Responsibility |
| --- | --- |
| `settlement` | Immutable records, SavedData, names, validation, authoritative creation and transactions |
| `interaction` | Recognize the exact Book + crouch + main-hand Bell interaction |
| `network` | Bounded naming payloads and server/client dispatch |
| `client` | Minimal naming screen and client-only registration |
| `component` | Persistent, network-synchronized settlement UUID component |
| `item` | Non-stackable ledger, server lookup, inventory/drop delivery |
| `config` | Bounded per-world server settings |
| `command` | Permission-gated debug commands |

The screen and network handler never modify SavedData. `SettlementManager` owns final revalidation, registration, delivery, and charging. Both competing submissions run synchronously on the server thread. Client classes are isolated from common initialization.

## Development references

The project uses the [official NeoForge 1.21.1 ModDevGradle template](https://github.com/NeoForgeMDKs/MDK-1.21.1-ModDevGradle). Persistence follows [NeoForge's SavedData API](https://docs.neoforged.net/docs/1.21.1/datastorage/saveddata/), and networking uses [registered payloads](https://docs.neoforged.net/docs/1.21.1/networking/payload/).

The Gradle wrapper retains its upstream Apache 2.0 notices; its license is included in `gradle/LICENSE`. The mod's metadata currently uses `All Rights Reserved`, leaving a publication license decision to the project author.
