package dev.conner.hometown.client;

import com.google.gson.JsonParser;
import dev.conner.hometown.network.RequestTownLedgerPayload;
import dev.conner.hometown.network.TownLedgerSnapshotPayload;
import dev.conner.hometown.network.data.ResidentSummary;
import dev.conner.hometown.network.data.TownLedgerSnapshot;
import dev.conner.hometown.settlement.Settlement;
import dev.conner.hometown.settlement.SettlementStats;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.SharedConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.locale.Language;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.network.chat.Style;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.Bootstrap;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.network.PacketDistributor;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Answers;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/** Exercises the actual screen drawing methods with a recording graphics backend, without OpenGL. */
class TownLedgerScreenTest {
    @BeforeAll static void bootstrap() { SharedConstants.tryDetectVersion(); Bootstrap.bootStrap(); }

    private TownLedgerScreen screen(int width, int height) throws Exception {
        var screen = spy(new TownLedgerScreen(InteractionHand.MAIN_HAND));
        var font = mock(Font.class);
        when(font.width(anyString())).thenAnswer(call -> ((String)call.getArgument(0)).length() * 6);
        when(font.plainSubstrByWidth(anyString(), anyInt())).thenAnswer(call -> {
            String text = call.getArgument(0); int length = call.getArgument(1);
            return text.substring(0, Math.min(text.length(), Math.max(0, length / 6)));
        });
        var fontField = Screen.class.getDeclaredField("font"); fontField.setAccessible(true); fontField.set(screen, font);
        screen.width = width; screen.height = height;
        doNothing().when(screen).renderBackground(any(), anyInt(), anyInt(), anyFloat());
        var init = TownLedgerScreen.class.getDeclaredMethod("init"); init.setAccessible(true); init.invoke(screen);
        return screen;
    }

    private TownLedgerSnapshot snapshot() {
        var town = new Settlement(UUID.randomUUID(), "Dured", Level.OVERWORLD, new BlockPos(115, 68, 7), 64,
                UUID.randomUUID(), "GalrUI", 432000);
        var residents = List.of(new ResidentSummary("Mira", "entity.minecraft.villager.librarian", false),
                new ResidentSummary("", "hometown.ledger.unemployed", true));
        return TownLedgerSnapshot.of(town, new SettlementStats(2, 3, 1, 1, SettlementStats.Availability.COMPLETE, residents),
                TownLedgerSnapshot.BellState.MISSING, 0);
    }

    private List<String> draw(TownLedgerScreen screen) {
        var text = new ArrayList<String>();
        GuiGraphics graphics = mock(GuiGraphics.class, call -> {
            String method = call.getMethod().getName();
            if (method.equals("drawString") || method.equals("drawWordWrap") || method.equals("drawCenteredString")) {
                Object value = call.getArgument(1);
                text.add(value instanceof FormattedText formatted ? formatted.getString() : value.toString());
            }
            if (method.equals("fill")) {
                int x1 = call.getArgument(0), y1 = call.getArgument(1), x2 = call.getArgument(2), y2 = call.getArgument(3);
                assertTrue(x1 >= 0 && y1 >= 0 && x2 <= screen.width && y2 <= screen.height, "Book or tabs escaped the GUI area");
            }
            return Answers.RETURNS_DEFAULTS.answer(call);
        });
        screen.render(graphics, 0, 0, 0);
        return text;
    }

    @Test void allTabsRenderReadOnlyFactsAndFitNormalGuiScales() throws Exception {
        Language original = Language.getInstance();
        var translations = JsonParser.parseReader(new InputStreamReader(getClass().getResourceAsStream("/assets/hometown/lang/en_us.json"))).getAsJsonObject();
        Language.inject(new Language() {
            public String getOrDefault(String key, String fallback) { return translations.has(key) ? translations.get(key).getAsString() : original.getOrDefault(key, fallback); }
            public boolean has(String key) { return translations.has(key) || original.has(key); }
            public boolean isDefaultRightToLeft() { return false; }
            public FormattedCharSequence getVisualOrder(FormattedText text) { return FormattedCharSequence.forward(text.getString(), Style.EMPTY); }
        });
        try (var packets = mockStatic(PacketDistributor.class)) {
            var requests = new ArrayList<RequestTownLedgerPayload>();
            packets.when(() -> PacketDistributor.sendToServer(any(CustomPacketPayload.class)))
                    .thenAnswer(call -> { requests.add(call.getArgument(0)); return null; });
            for (int[] size : List.of(new int[]{320, 240}, new int[]{640, 360}, new int[]{960, 540})) {
                var screen = screen(size[0], size[1]);
                screen.requestPage(0);
                screen.receive(new TownLedgerSnapshotPayload(requests.getLast().requestId(), snapshot(), TownLedgerSnapshotPayload.Error.NONE));
                var overview = draw(screen);
                assertTrue(overview.contains("Population: 2"));
                assertTrue(overview.contains("Beds: 3"));
                assertTrue(overview.stream().anyMatch(s -> s.contains("Founding bell missing")));
                ((Button)screen.children().get(1)).onPress();
                var residents = draw(screen);
                assertTrue(residents.contains("Mira")); assertTrue(residents.contains("Child"));
                ((Button)screen.children().get(2)).onPress();
                assertEquals(6, draw(screen).stream().filter("Not yet tracked"::equals).count());
                ((Button)screen.children().get(3)).onPress();
                var history = draw(screen);
                assertTrue(history.contains("Day 18")); assertTrue(history.contains("Dured was founded by GalrUI."));
                assertFalse(screen.isPauseScreen());
            }
        } finally { Language.inject(original); }
    }

    @Test void staleResponsesAreIgnoredAndUnknownLedgerRendersAnError() throws Exception {
        try (var packets = mockStatic(PacketDistributor.class)) {
            var requests = new ArrayList<RequestTownLedgerPayload>();
            packets.when(() -> PacketDistributor.sendToServer(any(CustomPacketPayload.class)))
                    .thenAnswer(call -> { requests.add(call.getArgument(0)); return null; });
            var screen = screen(320, 240);
            screen.requestPage(0); int old = requests.getLast().requestId();
            screen.requestPage(1); int current = requests.getLast().requestId();
            screen.receive(new TownLedgerSnapshotPayload(old, snapshot(), TownLedgerSnapshotPayload.Error.NONE));
            assertFalse(draw(screen).contains("Dured"));
            screen.receive(new TownLedgerSnapshotPayload(current, null, TownLedgerSnapshotPayload.Error.UNKNOWN));
            assertTrue(draw(screen).stream().anyMatch(s -> s.contains("hometown.ledger.unknown")));
            assertTrue(screen.children().stream().anyMatch(widget -> widget instanceof Button button && button.visible && button.getMessage().getString().contains("hometown.ledger.retry")));
        }
    }
}
