# Town Ledger in-game acceptance

The existing foundation was reported working by the user. The following checks are for the new read-only Ledger milestone and remain pending in Minecraft.

Use Minecraft 1.21.1, NeoForge 21.1.250, Java 21, and the updated Hometown JAR on both client and server.

## Overview live updates

- [ ] Open a Ledger for a town with two villagers, two beds, one adult Farmer, and one unemployed villager. Expect Population 2, Beds 2, Employed 1, Professions 1.
- [ ] Add a Librarian and one bed. Close and reopen. Expect 3, 3, 2, 2.
- [ ] Remove the Farmer's workstation and wait until Minecraft actually changes its profession. Close and reopen. Expect 3, 3, 1, 1.
- [ ] Add a baby: population rises; employed count and profession diversity do not.
- [ ] Confirm town name, original founder/day, dimension, and Bell coordinates match the saved record.

## Residents and book

- [ ] Four bookmark tabs work and clearly indicate the active tab.
- [ ] Residents shows each loaded living villager, a custom name or Villager fallback, profession, and Adult/Child.
- [ ] With more than four residents, use arrows to reach every resident. Reopen after a profession/name change to see fresh information.
- [ ] Hover long truncated lines to read their supplied full text.
- [ ] Development shows all six specified categories as Not yet tracked; History contains only the founding event.
- [ ] Check normal GUI scales, mouse clicks, keyboard tab focus, and Escape. Gameplay continues while the book is open.
- [ ] Close immediately after requesting data; a delayed reply does not reopen the book.

## Bell, unavailable data, invalid links

- [ ] Break the founding Bell. The Ledger still opens and gives the saved replacement coordinates.
- [ ] Replace the Bell at those coordinates and reopen. The missing warning disappears.
- [ ] Open from far away or another dimension with settlement chunks unloaded. Data is marked partial/unavailable and no chunks are forced to load.
- [ ] Read a Ledger with an unknown UUID. A clean error is shown without a crash.
- [ ] Retry a briefly rate-limited request; the book recovers normally.

## Existing-world regression

- [ ] Close Minecraft completely, restart, open the same world, and use an existing Ledger. Identity and live statistics work without migration.
- [ ] Recheck Book + crouch + Bell founding, failed-validation Book preservation, duplicate Bell rejection, and full-inventory Ledger delivery.
- [ ] Confirm idle server behavior has no background settlement scans or log spam.

The automated suite covers the corresponding server logic and drawing code, but these real Minecraft checks are still required before certifying the milestone complete in-game.

## v0.2.1 sharpness — pending in-game verification

At Minecraft GUI scales 2, 3, and 4, open each of Overview, Residents, Development, and History. Confirm sharp text and parchment edges, unchanged bookmark styling and behavior, and no page content outside the ledger. Include resident paging and hover tooltips. Automated drawing-order and bounds checks pass, but actual GPU/font appearance must be confirmed in Minecraft.

## Rendering sharpness

Pending in-game: inspect all four pages, parchment, tabs, paging and tooltips at GUI scales 2, 3, and 4. Confirm crisp edges and no overflow. See RENDERING-FIX.md for automated checks.
