package dev.conner.hometown.settlement;

import dev.conner.hometown.Hometown;
import dev.conner.hometown.component.HometownDataComponents;
import dev.conner.hometown.item.HometownItems;
import dev.conner.hometown.network.RequestTownLedgerPayload;
import dev.conner.hometown.network.TownLedgerSnapshotPayload;
import dev.conner.hometown.network.data.TownLedgerSnapshot;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Blocks;

public final class TownLedgerService {
    private TownLedgerService() {}
    public static TownLedgerSnapshotPayload respond(ServerPlayer player, RequestTownLedgerPayload request) {
        return respond(player, request, HometownItems.TOWN_LEDGER.get(), HometownDataComponents.SETTLEMENT_ID.get());
    }

    static TownLedgerSnapshotPayload respond(ServerPlayer player, RequestTownLedgerPayload request,
            net.minecraft.world.item.Item ledgerItem,
            net.minecraft.core.component.DataComponentType<dev.conner.hometown.component.SettlementIdComponent> component) {
        var server = player.getServer();
        if (!server.isSameThread()) throw new IllegalStateException("Ledger scanning requires the server thread");
        var stack = player.getItemInHand(request.hand());
        if (!player.isAlive() || !stack.is(ledgerItem)) return error(request, TownLedgerSnapshotPayload.Error.HOLD_LEDGER);
        var link = stack.get(component);
        var town = link == null ? null : HometownSavedData.get(server).getSettlement(link.settlementId()).orElse(null);
        if (town == null) return error(request, TownLedgerSnapshotPayload.Error.UNKNOWN);
        // Existing vanilla cooldown is bounded per player and needs no maps or background tasks.
        if (player.getCooldowns().isOnCooldown(ledgerItem)) return error(request, TownLedgerSnapshotPayload.Error.WAIT);
        player.getCooldowns().addCooldown(ledgerItem, 5);
        var level = server.getLevel(town.dimension());
        var bellState = level == null || !SettlementQueries.loaded(level, town.bellPosition())
                ? TownLedgerSnapshot.BellState.UNAVAILABLE
                : level.getBlockState(town.bellPosition()).is(Blocks.BELL) ? TownLedgerSnapshot.BellState.PRESENT : TownLedgerSnapshot.BellState.MISSING;
        SettlementStats stats;
        try { stats = SettlementScanner.scan(level, town, SettlementValidator.Rules.current().verticalRadius()); }
        catch (RuntimeException exception) {
            Hometown.LOGGER.warn("Unable to scan Hometown [{}] for Ledger", town.id(), exception);
            stats = SettlementStats.unavailable();
        }
        return new TownLedgerSnapshotPayload(request.requestId(), TownLedgerSnapshot.of(town, stats, bellState, request.page()), TownLedgerSnapshotPayload.Error.NONE);
    }
    private static TownLedgerSnapshotPayload error(RequestTownLedgerPayload request, TownLedgerSnapshotPayload.Error error) {
        return new TownLedgerSnapshotPayload(request.requestId(), null, error);
    }
}
