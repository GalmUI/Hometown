package dev.conner.hometown.settlement;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.village.poi.PoiManager;
import net.minecraft.world.entity.ai.village.poi.PoiTypes;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Shared founding/ledger queries. Never obtain or request an unloaded world chunk. */
public final class SettlementQueries {
    private SettlementQueries() {}

    public static AABB bounds(BlockPos bell, int radius, int vertical) {
        return new AABB(bell).inflate(radius, vertical, radius);
    }

    public static List<Villager> residents(ServerLevel level, AABB bounds) {
        return level.getEntitiesOfClass(Villager.class, bounds,
                v -> v.getType() == EntityType.VILLAGER && v.isAlive()
                        && bounds.contains(v.position()) && loaded(level, v.blockPosition()));
    }

    public static int countBeds(ServerLevel level, BlockPos bell, int radius, int vertical, int limit) {
        if (limit <= 0) return 0;
        AABB bounds = bounds(bell, radius, vertical);
        int beds = 0;
        for (int x = (bell.getX() - radius) >> 4; x <= (bell.getX() + radius) >> 4; x++) {
            for (int z = (bell.getZ() - radius) >> 4; z <= (bell.getZ() + radius) >> 4; z++) {
                if (level.getChunkSource().getChunkNow(x, z) == null) continue;
                try (var records = level.getPoiManager().getInChunk(type -> type.is(PoiTypes.HOME),
                        new ChunkPos(x, z), PoiManager.Occupancy.ANY)) {
                    beds += (int)records.filter(p -> bounds.contains(Vec3.atCenterOf(p.getPos()))
                            && validBed(level, p.getPos())).limit(limit - beds).count();
                }
                if (beds >= limit) return beds;
            }
        }
        return beds;
    }

    private static boolean validBed(ServerLevel level, BlockPos pos) {
        if (!loaded(level, pos)) return false;
        BlockState head = level.getBlockState(pos);
        if (!(head.getBlock() instanceof BedBlock) || head.getValue(BedBlock.PART) != BedPart.HEAD
                || !BuiltInRegistries.BLOCK.getKey(head.getBlock()).getNamespace().equals("minecraft")) return false;
        BlockPos footPos = pos.relative(head.getValue(BedBlock.FACING).getOpposite());
        if (!loaded(level, footPos)) return false;
        BlockState foot = level.getBlockState(footPos);
        return foot.is(head.getBlock()) && foot.getValue(BedBlock.PART) == BedPart.FOOT
                && foot.getValue(BedBlock.FACING) == head.getValue(BedBlock.FACING);
    }

    public static boolean loaded(ServerLevel level, BlockPos pos) {
        return level.getChunkSource().getChunkNow(pos.getX() >> 4, pos.getZ() >> 4) != null;
    }
}
