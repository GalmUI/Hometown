package dev.conner.hometown.network.data;

import dev.conner.hometown.settlement.Settlement;
import dev.conner.hometown.settlement.SettlementStats;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;

public record TownLedgerSnapshot(UUID settlementId, String townName, String founderName, long foundedDay,
        String dimension, BlockPos bell, BellState bellState, SettlementStats.Availability availability,
        int population, int beds, int employed, int professionDiversity, int residentPage, int residentPages,
        List<ResidentSummary> residents) {
    public static final int PAGE_SIZE = 4;
    public enum BellState { PRESENT, MISSING, UNAVAILABLE }
    public TownLedgerSnapshot {
        bell = bell.immutable();
        residents = List.copyOf(residents);
        if (residents.size() > PAGE_SIZE || residentPage < 0 || residentPages < 1 || residentPage >= residentPages)
            throw new IllegalArgumentException("Invalid resident page");
    }

    public static TownLedgerSnapshot of(Settlement town, SettlementStats stats, BellState bellState, int requestedPage) {
        int pages = Math.max(1, (stats.residents().size() + PAGE_SIZE - 1) / PAGE_SIZE);
        int page = Math.max(0, Math.min(requestedPage, pages - 1));
        int start = page * PAGE_SIZE;
        return new TownLedgerSnapshot(town.id(), town.name(), town.founderName(), town.foundedDay(),
                town.dimension().location().toString(), town.bellPosition(), bellState, stats.availability(),
                stats.population(), stats.beds(), stats.employed(), stats.professionDiversity(), page, pages,
                stats.residents().subList(start, Math.min(start + PAGE_SIZE, stats.residents().size())));
    }
}
