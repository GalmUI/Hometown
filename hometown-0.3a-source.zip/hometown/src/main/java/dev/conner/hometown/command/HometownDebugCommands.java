package dev.conner.hometown.command;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import dev.conner.hometown.item.TownLedgerItem;
import dev.conner.hometown.settlement.HometownSavedData;
import dev.conner.hometown.settlement.Settlement;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.UuidArgument;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

public final class HometownDebugCommands {
    private static final SimpleCommandExceptionType UNKNOWN = new SimpleCommandExceptionType(Component.literal("Unknown hometown UUID."));
    private HometownDebugCommands() {}
    public static void register(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("hometown").requires(source -> source.hasPermission(2))
                .then(Commands.literal("debug")
                        .then(Commands.literal("room").executes(RoomDebugCommand::execute))
                        .then(Commands.literal("list").executes(HometownDebugCommands::list))
                        .then(Commands.literal("inspect").then(Commands.argument("uuid", UuidArgument.uuid()).executes(context -> {
                            Settlement town = resolve(context);
                            context.getSource().sendSuccess(() -> Component.literal(town.toTag().toString()), false);
                            return 1;
                        })))
                        .then(Commands.literal("remove").then(Commands.argument("uuid", UuidArgument.uuid()).executes(context -> {
                            Settlement town = resolve(context);
                            data(context).removeSettlement(town.id());
                            context.getSource().sendSuccess(() -> Component.literal("Removed Hometown '" + town.name() + "' [" + town.id() + "]."), true);
                            return 1;
                        })))
                        .then(Commands.literal("ledger").then(Commands.argument("uuid", UuidArgument.uuid()).executes(context -> {
                            Settlement town = resolve(context);
                            var player = context.getSource().getPlayerOrException();
                            if (!TownLedgerItem.deliver(player, TownLedgerItem.create(town))) {
                                context.getSource().sendFailure(Component.literal("Could not deliver the replacement ledger."));
                                return 0;
                            }
                            context.getSource().sendSuccess(() -> Component.literal("Delivered the ledger for " + town.name() + "."), true);
                            return 1;
                        })))));
    }

    private static int list(CommandContext<CommandSourceStack> context) {
        var towns = data(context).all();
        context.getSource().sendSuccess(() -> Component.literal("Known Hometowns: " + towns.size()), false);
        towns.forEach(town -> context.getSource().sendSuccess(() -> Component.literal(town.name() + " [" + town.id()
                + "] " + town.dimension().location() + " " + town.bellPosition().toShortString()), false));
        return towns.size();
    }
    private static HometownSavedData data(CommandContext<CommandSourceStack> context) {
        return HometownSavedData.get(context.getSource().getServer());
    }
    private static Settlement resolve(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        return data(context).getSettlement(UuidArgument.getUuid(context, "uuid")).orElseThrow(UNKNOWN::create);
    }
}
